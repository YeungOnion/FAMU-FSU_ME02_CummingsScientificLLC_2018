% for all combinations of models and datatypes

fitStuff = nan(4, 5, 11); % 4 params, 5 models, 11 datasets
mtype = {'haversine', 'halfsine', 'triangle', 'symmtriangle', 'square'};
for m = 1:length(mtype)
    for dataNum = 1:11
        [xbest, dv] = testAnyModel(dataNum, mtype{m});
        fitStuff(1,m, dataNum) = xbest(1);
        fitStuff(2,m, dataNum) = abs(xbest(3)-xbest(2));
        if strcmp('triangle', mtype{m})
            fitStuff(3,m, dataNum) = xbest(4);
        end
        fitStuff(4, m, dataNum) = dv;
        
    end
end

save('allFitSummary.mat', 'fitStuff', 'mtype')